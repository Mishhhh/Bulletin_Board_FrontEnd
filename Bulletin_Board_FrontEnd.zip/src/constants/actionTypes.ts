export enum ActionTypes {
    SET_POST= "Set_Post",
    SET_SINGLE_POST="Set_Single_Post",
    SET_USER_SESSION="Set_User_Session",
    REMOVE="remove",
    LOGOUT="LOGOUT"
};
